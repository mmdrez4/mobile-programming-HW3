import UIKit
import Foundation
import Darwin

extension String {
    var isInt: Bool {
        return Int(self) != nil
    }
}

class Category{
    static var categories = [Category]()
    var name: String
    var todos = [Todo]()
    init(name: String) {
        self.name = name
        Category.categories.append(self)
    }
    
    static func getByName(name: String) -> Category? {
        for category in categories {
            if category.name == name {
                return category
            }
        }
        return nil
    }
    
    func getTodos() -> [Todo] {
        return self.todos
    }
    
    func addTodos(Ids: [String]) -> () {
        for todoId in Ids {
            if todoId.isInt {
                let todo = Todo.getById(id: Int(todoId)!)
                todo.addCategory(category: self)
                self.todos.append(todo)
            }
        }
    }
    
}

class Todo{
    static var todoList = [Todo]()
    var title: String
    var content: String
    var priority: Int
    var id : Int
    static var start = 0
    var categories = [Category]()
    
    init(title: String, content: String, priority: Int) {
        self.title = title
        self.content = content
        self.priority = priority
        self.id = Todo.start
        Todo.todoList.append(self)
        Todo.start += 1
    }
    
    
    static func findTodo(title: String) -> Todo? {
        for todo in todoList {
            if todo.title == title {
                return todo
            }
        }
        return nil
    }
    
    static func getById(id: Int) -> Todo {
        return todoList[id]
    }
    
    func addCategory(category: Category) -> () {
        self.categories.append(category)
    }
    
    func change(parameter: String, changedParameter: String) -> Bool {
        switch parameter {
        case "title":
            self.title = changedParameter
        case "content":
            self.content = changedParameter
        case "priority":
            self.priority = Int(changedParameter) ?? self.priority
        default:
            return false
        }
        return true
    }
    
     static func remove(title: String) -> () {
//        let myTodo = Todo.findTodo(title: title)!
//        if let index = Todo.todoList.firstIndex(of: myTodo) {
//            Todo.todoList.remove(at: index)
//        }
        Todo.todoList.removeAll(where: { (td: Todo) -> Bool in
            return td.title == title
        })
//        self.userChosenHymns.removeAll(where: { (jm: JSONModel) -> Bool in
//            return jm.id == hymn.id
//          })
    }
    
    static func sort(parameter: String) -> ([Todo]) {
//        let tempArray = todoList.copy() as! Todo
        let tempArray = todoList
        if parameter == "time" {
            return(tempArray)
        }else if parameter == "title"{
            tempArray.sorted(by: { $0.title > $1.title })
        }else if parameter == "priority"{
            tempArray.sorted(by: { $0.priority > $1.priority })
        }
        return (tempArray)
    }
    
}

print("choose the Menu: \n 1.add new todo \n2.show Todo List \n3.change \n4.delete \n5.sort \n6.create a category \n7.add todos to the categories \n8.show category \n9.exit")

while true{
    var listOfTodos : [Todo]
    if let myInput = readLine() {
        let menu = Int(myInput)
        if menu == 1 {
            print("Input the title: ", terminator: "")
            let todoTitle = readLine()
            print("Input the content: ")
            let todoContent = readLine()
            print("Input the priority: ")
            let todoPriority = readLine()
            _ = Todo(title: todoTitle!, content: todoContent!, priority: Int(todoPriority ?? "1")!)
        } else if menu == 2{
            var i = 1
            for todo in Todo.todoList {
                print("\(i). \(todo.title) \(todo.content) \(todo.priority)")
                i+=1
            }
        } else if menu == 3{
            print("enter the title: ", terminator: "")
            let myTitle = readLine()
            let myTodo = Todo.findTodo(title: myTitle ?? "nothing")
            if myTodo != nil {
                print("enter the parameter you want to change:\n1.title 2.content 3.priority")
                let parameter = readLine()
                print("enter the alternative \(String(describing: parameter))")
                let changedParameter = readLine()
                if ((myTodo?.change(parameter: parameter!, changedParameter: changedParameter!)) != nil) {
                    print("you successfully changed \(String(describing: parameter))")
                }else{
                    print("invalid input!")
                }
            } else{
                print("There is no todo with this title!")
            }
        } else if menu == 4{
            print("enter the title: ", terminator: "")
            let myTitle = readLine()
            Todo.remove(title: myTitle!)
        } else if menu == 5{
            print("enter the parameter you want to be sorted by: 1.time 2.title 3.priority", terminator: "")
            let parameter = readLine()
            print("enter the method you want to sort: 1.ascending 2.descending", terminator: "")
            let method = readLine()
            listOfTodos = Todo.sort(parameter: parameter ?? "time")
            if method == "descending" {
                listOfTodos.reverse()
            }
            var i = 1
            for todo in listOfTodos {
                print("\(i). \(todo.title) \(todo.content) \(todo.priority)")
                i+=1
            }
        } else if menu == 6{
            print("enter the name of the category: ")
            let categoryName = readLine()
            _ = Category(name: categoryName!)
        } else if menu == 7{
            print("enter the name of the category: ")
            let categoryName = readLine()
            let category = Category.getByName(name: categoryName!)
            if category != nil {
                var i = 0
                for todo in Todo.todoList {
                    print("\(i). \(todo.title) \(todo.content)")
                    i+=1
                }
                print("enter the titles you want to add: ")
                let str = readLine()
                let ids = str?.components(separatedBy: " ")
                category!.addTodos(Ids: ids!)
                print("have been added successfully")
            }else{
                print("we don't have a category with name of \(categoryName ?? "your input")")
            }
            
        } else if menu == 8{
            print("enter the name of the category: ")
            let categoryName = readLine()
            let category = Category.getByName(name: categoryName!)
            
            if category != nil {
                var i = 1
                print("\(categoryName!): ")
                for todo in category!.getTodos() {
                    print("\(i). \(todo.title)")
                    i+=1
                }
            }else{
                print("we don't have a category with name of \(categoryName ?? "your input")")
            }
        }else if menu == 9{
            exit(0)
        }else{
            print("please input a valid menu")
        }
    }
//    else {
//        print("Why are you being so coy?")
//    }
    
}
